INSERT INTO `major` (`major_id`, `major_name`, `college_id`) VALUES (2, '计算机网络', 2);
INSERT INTO `major` (`major_id`, `major_name`, `college_id`) VALUES (3, '计算机应用', 2);
INSERT INTO `major` (`major_id`, `major_name`, `college_id`) VALUES (4, 'qwe', 1);
INSERT INTO `major` (`major_id`, `major_name`, `college_id`) VALUES (7, '计算机网络', 2);
INSERT INTO `major` (`major_id`, `major_name`, `college_id`) VALUES (9, '计算机网络', 3);
INSERT INTO `major` (`major_id`, `major_name`, `college_id`) VALUES (10, '这是一个专2 ', 3);
INSERT INTO `major` (`major_id`, `major_name`, `college_id`) VALUES (12, '第三个专业', 18);
INSERT INTO `major` (`major_id`, `major_name`, `college_id`) VALUES (14, '111', 20);
INSERT INTO `major` (`major_id`, `major_name`, `college_id`) VALUES (15, '999', 21);
