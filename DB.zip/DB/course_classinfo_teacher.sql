INSERT INTO `course_classinfo_teacher` (`class_id`, `course_id`, `isplaned`, `teacher_id`, `weekofopencourse`) VALUES (17, 16, 'yes', 11, 10);
