INSERT INTO `courseinfo` (`courseinfo_id`, `courseinfo_num`, `courseinfo_name`) VALUES (1, 100011, '高等数学');
INSERT INTO `courseinfo` (`courseinfo_id`, `courseinfo_num`, `courseinfo_name`) VALUES (2, 10002, '大学英语');
INSERT INTO `courseinfo` (`courseinfo_id`, `courseinfo_num`, `courseinfo_name`) VALUES (3, 100031, '毛概');
INSERT INTO `courseinfo` (`courseinfo_id`, `courseinfo_num`, `courseinfo_name`) VALUES (34, 111, '111');
INSERT INTO `courseinfo` (`courseinfo_id`, `courseinfo_num`, `courseinfo_name`) VALUES (35, 999, '999');
